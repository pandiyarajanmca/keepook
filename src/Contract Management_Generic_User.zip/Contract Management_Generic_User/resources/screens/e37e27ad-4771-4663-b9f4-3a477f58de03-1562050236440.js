jQuery("#simulation")
  .on("mouseenter dragenter", ".s-e37e27ad-4771-4663-b9f4-3a477f58de03 .mouseenter", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Text_36") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_36 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_36 span": {
                      "attributes": {
                        "color": "#005580"
                      }
                    }
                  },{
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_36": {
                      "attributes-ie": {
                        "-pie-background": "#F5F5F5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_37") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_37 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_37 span": {
                      "attributes": {
                        "color": "#005580"
                      }
                    }
                  },{
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_37": {
                      "attributes-ie": {
                        "-pie-background": "#F5F5F5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_38") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_38 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_38 span": {
                      "attributes": {
                        "color": "#005580"
                      }
                    }
                  },{
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_38": {
                      "attributes-ie": {
                        "-pie-background": "#F5F5F5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_39") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_39 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_39 span": {
                      "attributes": {
                        "color": "#005580"
                      }
                    }
                  },{
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_39": {
                      "attributes-ie": {
                        "-pie-background": "#F5F5F5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_40") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_40 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_40 span": {
                      "attributes": {
                        "color": "#005580"
                      }
                    }
                  },{
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_40": {
                      "attributes-ie": {
                        "-pie-background": "#F5F5F5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_41") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_41 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_41 span": {
                      "attributes": {
                        "color": "#005580"
                      }
                    }
                  },{
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_41": {
                      "attributes-ie": {
                        "-pie-background": "#F5F5F5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_42") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_42 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_42 span": {
                      "attributes": {
                        "color": "#005580"
                      }
                    }
                  },{
                    "#s-e37e27ad-4771-4663-b9f4-3a477f58de03 #s-Text_42": {
                      "attributes-ie": {
                        "-pie-background": "#F5F5F5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    }
  })
  .on("mouseleave dragleave", ".s-e37e27ad-4771-4663-b9f4-3a477f58de03 .mouseleave", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Text_36")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_37")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_38")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_39")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_40")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_41")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_42")) {
      jEvent.undoCases(jFirer);
    }
  });