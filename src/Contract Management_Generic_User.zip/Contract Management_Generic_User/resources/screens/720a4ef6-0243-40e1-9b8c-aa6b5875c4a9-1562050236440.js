jQuery("#simulation")
  .on("mouseenter dragenter", ".s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 .mouseenter", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Text_2") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_2 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_2 span": {
                      "attributes": {
                        "color": "#005580"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_2": {
                      "attributes-ie": {
                        "-pie-background": "#F5F5F5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_4") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_4 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_4 span": {
                      "attributes": {
                        "color": "#005580"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_4": {
                      "attributes-ie": {
                        "-pie-background": "#F5F5F5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_5") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_5 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_5 span": {
                      "attributes": {
                        "color": "#005580"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_5": {
                      "attributes-ie": {
                        "-pie-background": "#F5F5F5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_11") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_11 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_11 span": {
                      "attributes": {
                        "color": "#005580"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_11": {
                      "attributes-ie": {
                        "-pie-background": "#F5F5F5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_12") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_12 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_12 span": {
                      "attributes": {
                        "color": "#005580"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_12": {
                      "attributes-ie": {
                        "-pie-background": "#F5F5F5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_13") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_13 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_13 span": {
                      "attributes": {
                        "color": "#005580"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_13": {
                      "attributes-ie": {
                        "-pie-background": "#F5F5F5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_14") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_14 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#F5F5F5"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_14 span": {
                      "attributes": {
                        "color": "#005580"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_14": {
                      "attributes-ie": {
                        "-pie-background": "#F5F5F5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_6") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_6 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#EEEEEE",
                        "border-top-color": "#EEEEEE",
                        "border-right-color": "#EEEEEE",
                        "border-bottom-color": "#EEEEEE",
                        "border-left-color": "#EEEEEE"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_6": {
                      "attributes-ie": {
                        "border-top-color": "#EEEEEE",
                        "border-right-color": "#EEEEEE",
                        "border-bottom-color": "#EEEEEE",
                        "border-left-color": "#EEEEEE",
                        "-pie-background": "#EEEEEE",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_8") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_8 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#EEEEEE",
                        "border-top-color": "#EEEEEE",
                        "border-right-color": "#EEEEEE",
                        "border-bottom-color": "#EEEEEE",
                        "border-left-color": "#EEEEEE"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_8": {
                      "attributes-ie": {
                        "border-top-color": "#EEEEEE",
                        "border-right-color": "#EEEEEE",
                        "border-bottom-color": "#EEEEEE",
                        "border-left-color": "#EEEEEE",
                        "-pie-background": "#EEEEEE",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_20") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_20 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#EEEEEE",
                        "border-top-color": "#EEEEEE",
                        "border-right-color": "#EEEEEE",
                        "border-bottom-color": "#EEEEEE",
                        "border-left-color": "#EEEEEE"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_20": {
                      "attributes-ie": {
                        "border-top-color": "#EEEEEE",
                        "border-right-color": "#EEEEEE",
                        "border-bottom-color": "#EEEEEE",
                        "border-left-color": "#EEEEEE",
                        "-pie-background": "#EEEEEE",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_19") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_19 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#EEEEEE",
                        "border-top-color": "#EEEEEE",
                        "border-right-color": "#EEEEEE",
                        "border-bottom-color": "#EEEEEE",
                        "border-left-color": "#EEEEEE"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_19": {
                      "attributes-ie": {
                        "border-top-color": "#EEEEEE",
                        "border-right-color": "#EEEEEE",
                        "border-bottom-color": "#EEEEEE",
                        "border-left-color": "#EEEEEE",
                        "-pie-background": "#EEEEEE",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_10") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_10 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#EEEEEE",
                        "border-top-color": "#EEEEEE",
                        "border-right-color": "#EEEEEE",
                        "border-bottom-color": "#EEEEEE",
                        "border-left-color": "#EEEEEE"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_10": {
                      "attributes-ie": {
                        "border-top-color": "#EEEEEE",
                        "border-right-color": "#EEEEEE",
                        "border-bottom-color": "#EEEEEE",
                        "border-left-color": "#EEEEEE",
                        "-pie-background": "#EEEEEE",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_9") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_9 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#EEEEEE",
                        "border-top-color": "#EEEEEE",
                        "border-right-color": "#EEEEEE",
                        "border-bottom-color": "#EEEEEE",
                        "border-left-color": "#EEEEEE"
                      }
                    }
                  },{
                    "#s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 #s-Text_9": {
                      "attributes-ie": {
                        "border-top-color": "#EEEEEE",
                        "border-right-color": "#EEEEEE",
                        "border-bottom-color": "#EEEEEE",
                        "border-left-color": "#EEEEEE",
                        "-pie-background": "#EEEEEE",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    }
  })
  .on("mouseleave dragleave", ".s-720a4ef6-0243-40e1-9b8c-aa6b5875c4a9 .mouseleave", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#s-Text_2")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_4")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_5")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_11")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_12")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_13")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_14")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_6")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_8")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_20")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_19")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_10")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#s-Text_9")) {
      jEvent.undoCases(jFirer);
    }
  });