(function(window, undefined) {

  var jimLinks = {
    "8c9929d8-c51d-474a-97b6-74fcb9d1a6a2" : {
    },
    "76db1a26-6b8d-464c-bdc5-3bc779413293" : {
    },
    "3156b618-fc89-43e8-a1de-88a56423aa36" : {
    },
    "5fb174ed-5c1c-43b3-bdf1-597b767c6aec" : {
    },
    "467bbb4c-b74e-4c22-b173-89bc586ca000" : {
    },
    "720a4ef6-0243-40e1-9b8c-aa6b5875c4a9" : {
    },
    "e37e27ad-4771-4663-b9f4-3a477f58de03" : {
    },
    "f78e58de-35bb-4235-98ec-9ee73057a112" : {
    },
    "a2099fe4-2c84-4f73-8b84-a9373391084d" : {
    },
    "9ea0c399-bbe2-4116-9992-a0cb80c5cb4b" : {
    },
    "fe1c837c-95d5-4cd8-b19e-43cbd3d9e37c" : {
    },
    "6599d5f6-8150-4a34-ba4e-f260ee6f4013" : {
    },
    "eeeaac5c-65a0-4ee4-a39b-3a19bf006917" : {
    },
    "ae409b76-2219-4d0a-bdd6-975610e46752" : {
    },
    "b762049b-c04c-4ba6-87c4-019c425c51e5" : {
      "Button_4" : [
        "b6aab944-a927-4ee2-aa24-0fab7522ec02"
      ]
    },
    "164899df-bc92-42d7-8686-a059f69d21f5" : {
    },
    "97126a04-e8fb-4742-96ea-a6a3270340e5" : {
    },
    "e4118a0d-be42-4eb9-ad0e-7282ed645ba3" : {
    },
    "2e6dde53-37da-4ccc-a255-c58c44a05a42" : {
    },
    "66cad430-efc7-40ea-bff9-73b3055083a8" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);